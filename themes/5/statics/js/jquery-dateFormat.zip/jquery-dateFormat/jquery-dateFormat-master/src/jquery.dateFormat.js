// require dateFormat.js
// please check `dist/jquery.dateFormat.js` for a complete version
(function($) {
  $.format = DateFormat.format;
}(jQuery));
